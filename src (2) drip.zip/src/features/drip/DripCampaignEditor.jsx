import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "react-toastify";
import { ArrowLeft, Plus, Save } from "lucide-react";
import axios from "axios";
import { API_BASE, API_ENDPOINTS } from "../../config/api";
import { useAuth } from "../../context/AuthContext";
import StepCard from "./components/StepCard";
import StepEditor from "./components/StepEditor";
import TargetSelector from "./components/TargetSelector";
import TriggerSelector from "./components/TriggerSelector";

const DripCampaignEditor = () => {
  const navigate = useNavigate();
  const { campaignId } = useParams();
  const { user } = useAuth();
  const isEditMode = !!campaignId;

  const [loading, setLoading] = useState(false);
  const [templates, setTemplates] = useState([]);
  const [groups, setGroups] = useState([]);
  const [showStepEditor, setShowStepEditor] = useState(false);
  const [editingStep, setEditingStep] = useState(null);
  const [editingStepIndex, setEditingStepIndex] = useState(null);

  const [campaignData, setCampaignData] = useState({
    campaign_name: "",
    description: "",
    trigger_type: "manual",
    target_type: "all_contacts",
    target_ids: [],
    status: "draft",
  });

  const [steps, setSteps] = useState([]);

  useEffect(() => {
    fetchTemplates();
    fetchGroups();
    if (isEditMode) {
      fetchCampaignData();
    }
  }, [campaignId]);

  const fetchTemplates = async () => {
    try {
      const response = await axios.get(API_ENDPOINTS.TEMPLATES.GET_ALL, {
        params: { customer_id: user.customer_id },
        withCredentials: true,
        validateStatus: (status) => status < 500, // Don't throw on 404
      });
      
      // Handle both response formats (templates or data)
      const templateData = response.data.templates || response.data.data || [];
      console.log("📋 Templates fetched for drip campaign:", templateData.length, "templates");
      setTemplates(templateData);
      
      if (templateData.length === 0) {
        console.log("⚠️ No templates found. User needs to create templates first.");
      }
    } catch (error) {
      console.error("❌ Error fetching templates:", error);
      toast.error("Failed to load templates");
      setTemplates([]); // Set empty array on error
    }
  };

  const fetchGroups = async () => {
    try {
      const response = await axios.get(`${API_BASE}/returnGroups`, {
        params: { customer_id: user.customer_id },
        withCredentials: true,
      });
      setGroups(response.data.data || []);
    } catch (error) {
      console.error("Error fetching groups:", error);
    }
  };

  const fetchCampaignData = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`${API_BASE}/drip-campaigns/${campaignId}`, {
        params: { customer_id: user.customer_id },
        withCredentials: true,
      });

      const campaign = response.data.data;
      setCampaignData({
        campaign_name: campaign.campaign_name,
        description: campaign.description || "",
        trigger_type: campaign.trigger_type,
        target_type: campaign.target_type,
        target_ids: campaign.target_ids || [],
        status: campaign.status,
      });
      setSteps(campaign.steps || []);
    } catch (error) {
      console.error("Error fetching campaign:", error);
      toast.error("Failed to load campaign");
      navigate("/drip-campaigns");
    } finally {
      setLoading(false);
    }
  };

  const handleAddStep = () => {
    setEditingStep(null);
    setEditingStepIndex(null);
    setShowStepEditor(true);
  };

  const handleEditStep = (step, index) => {
    setEditingStep(step);
    setEditingStepIndex(index);
    setShowStepEditor(true);
  };

  const handleSaveStep = (stepData) => {
    if (editingStepIndex !== null) {
      // Update existing step
      const updatedSteps = [...steps];
      updatedSteps[editingStepIndex] = {
        ...updatedSteps[editingStepIndex],
        ...stepData,
        step_order: editingStepIndex,
      };
      setSteps(updatedSteps);
      toast.success("Step updated successfully");
    } else {
      // Add new step
      setSteps([
        ...steps,
        {
          ...stepData,
          step_order: steps.length,
        },
      ]);
      toast.success("Step added successfully");
    }
    setShowStepEditor(false);
    setEditingStep(null);
    setEditingStepIndex(null);
  };

  const handleDeleteStep = (index) => {
    if (!window.confirm("Are you sure you want to delete this step?")) return;

    const updatedSteps = steps.filter((_, i) => i !== index);
    // Reorder remaining steps
    const reorderedSteps = updatedSteps.map((step, i) => ({
      ...step,
      step_order: i,
    }));
    setSteps(reorderedSteps);
    toast.success("Step deleted successfully");
  };

  const handleSaveCampaign = async (status = "draft") => {
    if (!campaignData.campaign_name.trim()) {
      toast.error("Please enter a campaign name");
      return;
    }

    if (steps.length === 0) {
      toast.error("Please add at least one step");
      return;
    }

    try {
      setLoading(true);

      const payload = {
        ...campaignData,
        customer_id: user.customer_id,
        status,
        steps,
      };

      if (isEditMode) {
        await axios.put(`${API_BASE}/drip-campaigns/${campaignId}`, payload, {
          withCredentials: true,
        });
        toast.success("Campaign updated successfully");
      } else {
        await axios.post(`${API_BASE}/drip-campaigns`, payload, {
          withCredentials: true,
        });
        toast.success("Campaign created successfully");
      }

      navigate("/drip-campaigns", { state: { refresh: true } });
    } catch (error) {
      console.error("Error saving campaign:", error);
      toast.error(error.response?.data?.message || "Failed to save campaign");
    } finally {
      setLoading(false);
    }
  };

  if (loading && isEditMode) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#0AA89E]"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      {/* Header */}
      <div className="max-w-5xl mx-auto mb-6">
        <button
          onClick={() => navigate("/drip-campaigns")}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-4"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Campaigns
        </button>

        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              {isEditMode ? "Edit Campaign" : "Create New Campaign"}
            </h1>
            <p className="text-gray-600 mt-1">
              Set up your automated WhatsApp message sequence
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleSaveCampaign("draft")}
              disabled={loading}
              className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              Save Draft
            </button>
            <button
              onClick={() => handleSaveCampaign("active")}
              disabled={loading}
              className="px-4 py-2 bg-[#0AA89E] text-white rounded-lg hover:bg-[#099890] transition-colors flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              Save & Activate
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Campaign Settings */}
        <div className="lg:col-span-1 space-y-4">
          {/* Basic Info */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Campaign Details
            </h3>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Campaign Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={campaignData.campaign_name}
                  onChange={(e) =>
                    setCampaignData({
                      ...campaignData,
                      campaign_name: e.target.value,
                    })
                  }
                  placeholder="e.g., Welcome Series"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0AA89E]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  value={campaignData.description}
                  onChange={(e) =>
                    setCampaignData({
                      ...campaignData,
                      description: e.target.value,
                    })
                  }
                  placeholder="Describe your campaign..."
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0AA89E]"
                />
              </div>
            </div>
          </div>

          {/* Trigger */}
          <TriggerSelector
            value={campaignData.trigger_type}
            onChange={(value) =>
              setCampaignData({ ...campaignData, trigger_type: value })
            }
          />

          {/* Target Audience */}
          <TargetSelector
            targetType={campaignData.target_type}
            targetIds={campaignData.target_ids}
            groups={groups}
            onChange={(targetType, targetIds) =>
              setCampaignData({
                ...campaignData,
                target_type: targetType,
                target_ids: targetIds,
              })
            }
          />
        </div>

        {/* Right Column - Steps */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-900">
                Message Sequence ({steps.length} steps)
              </h3>
              <button
                onClick={handleAddStep}
                className="flex items-center gap-2 px-4 py-2 bg-[#0AA89E] text-white rounded-lg hover:bg-[#099890] transition-colors"
              >
                <Plus className="w-4 h-4" />
                Add Step
              </button>
            </div>

            {steps.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-gray-500 mb-4">No steps added yet</p>
                <button
                  onClick={handleAddStep}
                  className="text-[#0AA89E] hover:underline"
                >
                  Add your first step
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {steps.map((step, index) => (
                  <StepCard
                    key={index}
                    step={step}
                    index={index}
                    totalSteps={steps.length}
                    onEdit={handleEditStep}
                    onDelete={handleDeleteStep}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Step Editor Modal */}
      {showStepEditor && (
        <StepEditor
          step={editingStep}
          index={editingStepIndex ?? steps.length}
          templates={templates}
          onSave={handleSaveStep}
          onClose={() => {
            setShowStepEditor(false);
            setEditingStep(null);
            setEditingStepIndex(null);
          }}
        />
      )}
    </div>
  );
};

export default DripCampaignEditor;
