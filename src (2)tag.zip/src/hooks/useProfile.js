import { useState, useEffect, useCallback } from "react";
import { useAuth } from "../context/AuthContext";
import ProfileService from "../services/profileService";
import { showSuccessToast, showErrorToast } from "../utils/toastConfig";

export const useProfile = () => {
  const { user, fetchWabaInfo } = useAuth();
  const [profileData, setProfileData] = useState({
    details: null,
    about: null,
    photo: null,
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Load profile data when component mounts or user changes
  const loadProfileData = useCallback(async () => {
    if (!user?.customer_id) return;

    setLoading(true);
    setError(null);

    try {
      const completeProfile = await ProfileService.getCompleteProfile(user.customer_id);
      setProfileData(completeProfile);
    } catch (err) {
      console.error("Error loading profile data:", err);
      setError(err.response?.data?.message || err.message || "Failed to load profile data");
      showErrorToast("Failed to load profile data");
    } finally {
      setLoading(false);
    }
  }, [user?.customer_id]);

  // Update profile details
  const updateProfileDetails = useCallback(async (profileDetails) => {
    if (!user?.customer_id) return;

    setLoading(true);
    setError(null);

    try {
      const response = await ProfileService.updateProfileDetails(user.customer_id, profileDetails);
      
      // Update local state
      setProfileData(prev => ({
        ...prev,
        details: response.data || response
      }));

      // Refresh WABA info
      await fetchWabaInfo(user.customer_id);
      
      showSuccessToast("Profile details updated successfully");
      return response;
    } catch (err) {
      console.error("Error updating profile details:", err);
      const errorMessage = err.response?.data?.message || err.message || "Failed to update profile details";
      setError(errorMessage);
      showErrorToast(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  }, [user?.customer_id, fetchWabaInfo]);

  // Update profile about
  const updateProfileAbout = useCallback(async (about) => {
    if (!user?.customer_id) return;

    setLoading(true);
    setError(null);

    try {
      const response = await ProfileService.updateProfileAbout(user.customer_id, about);
      
      // Update local state
      setProfileData(prev => ({
        ...prev,
        about: response.data || response
      }));

      // Refresh WABA info
      await fetchWabaInfo(user.customer_id);
      
      showSuccessToast("Profile about updated successfully");
      return response;
    } catch (err) {
      console.error("Error updating profile about:", err);
      const errorMessage = err.response?.data?.message || err.message || "Failed to update profile about";
      setError(errorMessage);
      showErrorToast(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  }, [user?.customer_id, fetchWabaInfo]);

  // Update profile photo
  const updateProfilePhoto = useCallback(async (imageFile) => {
    if (!user?.customer_id || !imageFile) return;

    setLoading(true);
    setError(null);

    try {
      const response = await ProfileService.updateProfilePhoto(user.customer_id, imageFile);
      
      // Update local state
      setProfileData(prev => ({
        ...prev,
        photo: response.data || response
      }));

      // Refresh WABA info
      await fetchWabaInfo(user.customer_id);
      
      showSuccessToast("Profile photo updated successfully");
      return response;
    } catch (err) {
      console.error("Error updating profile photo:", err);
      const errorMessage = err.response?.data?.message || err.message || "Failed to update profile photo";
      setError(errorMessage);
      showErrorToast(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  }, [user?.customer_id, fetchWabaInfo]);

  // Sync WABA info
  const syncWabaInfo = useCallback(async () => {
    if (!user?.customer_id) return;

    setLoading(true);
    setError(null);

    try {
      const response = await ProfileService.syncWabaInfo(user.customer_id);
      
      // Refresh WABA info in context
      await fetchWabaInfo(user.customer_id);
      
      // Reload profile data
      await loadProfileData();
      
      showSuccessToast("WABA info synced successfully");
      return response;
    } catch (err) {
      console.error("Error syncing WABA info:", err);
      const errorMessage = err.response?.data?.message || err.message || "Failed to sync WABA info";
      setError(errorMessage);
      showErrorToast(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  }, [user?.customer_id, fetchWabaInfo, loadProfileData]);

  // Load profile data on mount
  useEffect(() => {
    loadProfileData();
  }, [loadProfileData]);

  return {
    profileData,
    loading,
    error,
    loadProfileData,
    updateProfileDetails,
    updateProfileAbout,
    updateProfilePhoto,
    syncWabaInfo,
  };
};
