// Tag utility functions

// Extract tag ID from different possible field names (backend uses 'id')
export const getTagId = (tag) => tag?.id || tag?.tag_id || tag?._id || null;

// Extract tag name from different possible field names (backend uses 'tag')
export const getTagName = (tag) => tag?.tag || tag?.tag_name || tag?.name || "Untitled";

// Extract tag color with default fallback
export const getTagColor = (tag, defaultColor = "#0AA89E") => 
  tag?.tag_color || tag?.color || defaultColor;

// Extract category name from different possible field names
export const getCategoryName = (tag) => 
  tag?.category_name || tag?.category || "Uncategorized";

// Check if tag is active
export const isTagActive = (tag) => 
  tag?.is_active !== undefined ? tag.is_active : tag?.status !== "inactive";

// Format date for display
export const formatTagDate = (dateValue) => {
  try {
    if (!dateValue) return null;
    const d = new Date(dateValue);
    if (isNaN(d)) return null;
    return d.toLocaleDateString(undefined, { 
      day: "2-digit", 
      month: "short", 
      year: "numeric" 
    });
  } catch {
    return null;
  }
};

// Filter tags by search term
export const filterTags = (tags, searchTerm) => {
  if (!searchTerm) return tags;
  const searchLower = searchTerm.toLowerCase();
  return tags.filter((tag) => {
    const tagName = getTagName(tag);
    const categoryName = getCategoryName(tag);
    return (
      tagName.toLowerCase().includes(searchLower) ||
      categoryName.toLowerCase().includes(searchLower)
    );
  });
};

// Normalize tag data to consistent format
export const normalizeTag = (tag) => ({
  id: getTagId(tag),
  name: getTagName(tag),
  color: getTagColor(tag),
  category: getCategoryName(tag),
  isActive: isTagActive(tag),
  firstMessageEnabled: !!tag?.first_message_enabled,
  customerJourney: !!tag?.customer_journey,
  createdAt: tag?.created_at || tag?.createdAt || null,
  raw: tag,
});
