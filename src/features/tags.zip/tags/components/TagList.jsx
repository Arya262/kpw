import React from "react";
import { getTagName, getTagColor } from "../utils/tagUtils";

const TagList = ({ 
  tags = [], 
  size = "sm", 
  maxDisplay = 3,
  emptyMessage = "No tags"
}) => {
  if (!tags || tags.length === 0) {
    return <span className="text-gray-400 text-xs">{emptyMessage}</span>;
  }

  const sizeClasses = {
    xs: "px-2 py-0.5 text-[10px]",
    sm: "px-2 py-1 text-xs",
    md: "px-3 py-1 text-sm",
  };

  const displayTags = tags.slice(0, maxDisplay);
  const remainingCount = tags.length - maxDisplay;

  return (
    <div className="flex flex-wrap gap-1">
      {displayTags.map((tag, index) => {
        const tagName = getTagName(tag);
        const tagColor = getTagColor(tag);
        
        return (
          <span
            key={tag?.id || tag?.tag_id || index}
            className={`inline-block rounded-full font-medium ${sizeClasses[size] || sizeClasses.sm}`}
            style={{ backgroundColor: `${tagColor}30`, color: tagColor }}
          >
            {tagName}
          </span>
        );
      })}
      {remainingCount > 0 && (
        <span className={`inline-block rounded-full bg-gray-200 text-gray-600 ${sizeClasses[size] || sizeClasses.sm}`}>
          +{remainingCount}
        </span>
      )}
    </div>
  );
};

export default TagList;
