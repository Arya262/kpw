import { createPortal } from "react-dom";

const FloatingSubmenu = ({
  children,
  position,
  visible,
  setSubmenuHovered,
  setActiveSubmenu,
  setSubmenuPosition,
}) => {
  if (!visible || !position) return null;

  return createPortal(
    <div
      className="absolute z-[9999] bg-white shadow-lg rounded-lg min-w-[180px] p-2"
      style={{
        top: `${position.top}px`,
        left: `${position.left}px`,
      }}
      onMouseEnter={() => setSubmenuHovered(true)}
      onMouseLeave={() => {
        setSubmenuHovered(false);
        setActiveSubmenu(null);
        setSubmenuPosition(null);
      }}
    >
      {children}
    </div>,
    document.body
  );
};

export default FloatingSubmenu;
